// =============================================
// config/db.js - MongoDB Connection Setup
// =============================================

const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    // Connect to MongoDB using the URI from .env
    const conn = await mongoose.connect(process.env.MONGO_URI);

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`❌ MongoDB Connection Error: ${error.message}`);
    // Exit the process if DB connection fails — app can't run without it
    process.exit(1);
  }
};

module.exports = connectDB;
