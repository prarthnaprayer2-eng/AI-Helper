# 🎓 CampusGenius Backend API

A complete RESTful backend for **CampusGenius** — the AI College Helper app.
Built with **Node.js**, **Express.js**, and **MongoDB (Mongoose)**.

---

## 📁 Folder Structure

```
campusgenius-backend/
├── config/
│   └── db.js                  # MongoDB connection
├── controllers/
│   ├── authController.js      # Signup, login, profile
│   ├── noteController.js      # Notes CRUD
│   ├── attendanceController.js# Attendance tracking
│   ├── assignmentController.js# Assignment management
│   ├── financeController.js   # Expense tracking
│   └── plannerController.js   # AI study planner
├── middleware/
│   └── authMiddleware.js      # JWT protection
├── models/
│   ├── User.js
│   ├── Note.js
│   ├── Attendance.js
│   ├── Assignment.js
│   └── Expense.js
├── routes/
│   ├── authRoutes.js
│   ├── noteRoutes.js
│   ├── attendanceRoutes.js
│   ├── assignmentRoutes.js
│   ├── financeRoutes.js
│   └── plannerRoutes.js
├── .env.example               # Sample environment variables
├── .gitignore
├── package.json
└── server.js                  # Main entry point
```

---

## ⚙️ Local Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
```bash
cp .env.example .env
```
Edit `.env` and fill in:
```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/campusgenius
JWT_SECRET=your_super_secret_key_here
JWT_EXPIRES_IN=7d
```

### 3. Run the Server
```bash
# Development (auto-restarts on file changes)
npm run dev

# Production
npm start
```

Server runs at: `http://localhost:5000`

---

## 🌐 API Reference

All protected routes require this header:
```
Authorization: Bearer <your_jwt_token>
```

---

### 🔐 Auth Routes

| Method | Endpoint | Auth | Body | Description |
|--------|----------|------|------|-------------|
| POST | `/api/auth/signup` | ❌ | `{ name, email, password }` | Register new user |
| POST | `/api/auth/login` | ❌ | `{ email, password }` | Login, returns token |
| GET | `/api/auth/me` | ✅ | — | Get my profile |

**Signup Example:**
```json
POST /api/auth/signup
{
  "name": "Aryan Singh",
  "email": "aryan@college.edu",
  "password": "mypassword123"
}
```

**Response:**
```json
{
  "message": "Account created successfully!",
  "user": { "id": "...", "name": "Aryan Singh", "email": "aryan@college.edu" },
  "token": "eyJhbGciOiJIUzI1..."
}
```

---

### 📝 Notes Routes

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/notes` | ✅ | Get all my notes |
| POST | `/api/notes` | ✅ | Create a note |
| GET | `/api/notes/:id` | ✅ | Get one note |
| DELETE | `/api/notes/:id` | ✅ | Delete a note |

**Create Note Body:**
```json
{
  "title": "Calculus Chapter 3",
  "content": "Integration by parts: ∫u dv = uv − ∫v du",
  "subject": "Mathematics",
  "tags": ["calculus", "exam", "important"]
}
```

---

### 📅 Attendance Routes

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/attendance` | ✅ | Get all subjects |
| POST | `/api/attendance` | ✅ | Add a subject |
| PUT | `/api/attendance/:id` | ✅ | Update attendance |
| DELETE | `/api/attendance/:id` | ✅ | Remove a subject |

**Add Subject Body:**
```json
{
  "subject": "Data Structures",
  "totalClasses": 30,
  "attendedClasses": 25,
  "minimumRequired": 75
}
```

**Update Attendance Body (mark one class attended):**
```json
{
  "totalClasses": 31,
  "attendedClasses": 26
}
```

---

### 📋 Assignment Routes

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/assignments` | ✅ | All assignments |
| GET | `/api/assignments/upcoming` | ✅ | Upcoming incomplete tasks |
| POST | `/api/assignments` | ✅ | Add assignment |
| PUT | `/api/assignments/:id/complete` | ✅ | Toggle done/undone |
| DELETE | `/api/assignments/:id` | ✅ | Delete assignment |

**Create Assignment Body:**
```json
{
  "title": "OS Lab Report",
  "subject": "Operating Systems",
  "description": "Write about scheduling algorithms",
  "deadline": "2024-12-20T23:59:00",
  "priority": "high"
}
```

---

### 💰 Finance Routes

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/finance` | ✅ | All expenses + totals |
| POST | `/api/finance` | ✅ | Add expense |
| GET | `/api/finance/summary` | ✅ | This month's summary |
| DELETE | `/api/finance/:id` | ✅ | Delete expense |

**Add Expense Body:**
```json
{
  "title": "Lunch at canteen",
  "amount": 120,
  "category": "food",
  "date": "2024-12-10",
  "note": "Paid with UPI"
}
```

**Categories:** `food`, `transport`, `books`, `entertainment`, `rent`, `health`, `shopping`, `other`

---

### 🤖 AI Planner Routes

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/planner/generate` | ✅ | Generate study plan |
| POST | `/api/planner/tips` | ✅ | Get subject-specific tips |

**Generate Plan Body:**
```json
{
  "availableHoursPerDay": 4,
  "tasks": [
    { "name": "Math Assignment", "deadline": "2024-12-15", "estimatedHours": 3 },
    { "name": "Physics Lab Report", "deadline": "2024-12-17", "estimatedHours": 2 },
    { "name": "DSA Revision", "deadline": "2024-12-18", "estimatedHours": 5 }
  ]
}
```

**Get Tips Body:**
```json
{ "subject": "programming" }
```

---

## 🚀 Deploy on Render (Step by Step)

### Step 1: MongoDB Atlas (Free Cloud Database)

1. Go to [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas) → Sign up free
2. Create a **free M0 cluster** (choose any region)
3. Go to **Database Access** → Add New User → set username + password
4. Go to **Network Access** → Add IP Address → `0.0.0.0/0` (allow from anywhere)
5. Go to **Connect** → **Drivers** → Copy your connection string:
   ```
   mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/campusgenius
   ```
   Replace `<username>` and `<password>` with what you set in step 3.

---

### Step 2: Push Code to GitHub

```bash
# Initialize git in your project folder
git init
git add .
git commit -m "feat: initial CampusGenius backend"

# Create a repo on github.com, then:
git remote add origin https://github.com/YOUR_USERNAME/campusgenius-backend.git
git branch -M main
git push -u origin main
```

> ⚠️ Make sure `.env` is in your `.gitignore` — never push secret keys!

---

### Step 3: Deploy on Render

1. Go to [render.com](https://render.com) → Sign up (free)
2. Click **New +** → **Web Service**
3. Connect your GitHub account and select your repo
4. Fill in deployment settings:

   | Setting | Value |
   |---------|-------|
   | **Name** | `campusgenius-api` |
   | **Region** | Closest to you |
   | **Branch** | `main` |
   | **Build Command** | `npm install` |
   | **Start Command** | `npm start` |
   | **Instance Type** | Free |

5. Scroll to **Environment Variables** → Click **Add Environment Variable**:

   | Key | Value |
   |-----|-------|
   | `MONGO_URI` | Your Atlas connection string |
   | `JWT_SECRET` | A long random string (min 32 chars) |
   | `JWT_EXPIRES_IN` | `7d` |
   | `NODE_ENV` | `production` |

6. Click **Create Web Service** → Render builds and deploys automatically!

7. Your API will be live at:
   ```
   https://campusgenius-api.onrender.com
   ```

---

### Step 4: Test Your Live API

Use Postman, Insomnia, or curl:
```bash
# Health check
curl https://campusgenius-api.onrender.com/

# Signup
curl -X POST https://campusgenius-api.onrender.com/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@test.com","password":"test1234"}'
```

---

## 🔒 Security Notes

- Passwords are hashed using **bcrypt** (never stored as plain text)
- JWT tokens expire after 7 days
- Every user can only access **their own** data
- Never share your `JWT_SECRET` or `MONGO_URI`

---

## 🛠️ Tech Stack

| Technology | Purpose |
|------------|---------|
| Node.js | Runtime environment |
| Express.js | Web framework |
| MongoDB | Database |
| Mongoose | MongoDB object modeling |
| bcryptjs | Password hashing |
| jsonwebtoken | JWT authentication |
| dotenv | Environment variable management |
| cors | Cross-Origin Resource Sharing |

---

## 📞 Connecting to Frontend

In your React/Next.js frontend, set the base URL:
```js
// In your frontend .env
VITE_API_URL=https://campusgenius-api.onrender.com

// Usage
const res = await fetch(`${import.meta.env.VITE_API_URL}/api/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ email, password }),
});
const data = await res.json();
// Save data.token to localStorage for future requests
```
