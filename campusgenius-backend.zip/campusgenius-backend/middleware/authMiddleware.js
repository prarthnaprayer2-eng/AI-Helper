// =============================================
// middleware/authMiddleware.js - JWT Protection
// =============================================
// This middleware runs BEFORE protected route handlers.
// It checks if the request has a valid JWT token.
// Usage: Add `protect` to any route that needs login.

const jwt = require("jsonwebtoken");
const User = require("../models/User");

const protect = async (req, res, next) => {
  let token;

  // Check if Authorization header exists and starts with "Bearer"
  // Format: Authorization: Bearer <token>
  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    try {
      // Extract token from header (remove "Bearer " prefix)
      token = req.headers.authorization.split(" ")[1];

      // Verify the token using our secret key
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Attach the user (without password) to the request object
      // Now any route handler can access req.user to know WHO is logged in
      req.user = await User.findById(decoded.id).select("-password");

      if (!req.user) {
        return res.status(401).json({ message: "User not found. Token invalid." });
      }

      // Call next() to pass control to the actual route handler
      next();
    } catch (error) {
      console.error("Token verification failed:", error.message);
      return res.status(401).json({ message: "Not authorized. Token failed." });
    }
  }

  if (!token) {
    return res.status(401).json({ message: "Not authorized. No token provided." });
  }
};

module.exports = { protect };
