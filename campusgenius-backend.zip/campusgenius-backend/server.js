// =============================================
// server.js - Main Entry Point for CampusGenius
// =============================================

// Load environment variables from .env file FIRST
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

// Initialize Express app
const app = express();

// ---- Connect to MongoDB ----
connectDB();

// ---- Middleware ----
app.use(cors()); // Allow cross-origin requests (important for frontend)
app.use(express.json()); // Parse incoming JSON request bodies

// ---- API Routes ----
// Each route file handles a specific feature of CampusGenius
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/notes", require("./routes/noteRoutes"));
app.use("/api/attendance", require("./routes/attendanceRoutes"));
app.use("/api/assignments", require("./routes/assignmentRoutes"));
app.use("/api/finance", require("./routes/financeRoutes"));
app.use("/api/planner", require("./routes/plannerRoutes"));

// ---- Root Route (Health Check) ----
app.get("/", (req, res) => {
  res.json({
    message: "🎓 CampusGenius API is running!",
    version: "1.0.0",
    endpoints: {
      auth: "/api/auth",
      notes: "/api/notes",
      attendance: "/api/attendance",
      assignments: "/api/assignments",
      finance: "/api/finance",
      planner: "/api/planner",
    },
  });
});

// ---- 404 Handler (for unknown routes) ----
app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

// ---- Global Error Handler ----
app.use((err, req, res, next) => {
  console.error("Unhandled Error:", err.stack);
  res.status(500).json({ message: "Internal Server Error", error: err.message });
});

// ---- Start Server ----
// Render sets PORT automatically; fallback to 5000 for local dev
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 CampusGenius server running on port ${PORT}`);
});
