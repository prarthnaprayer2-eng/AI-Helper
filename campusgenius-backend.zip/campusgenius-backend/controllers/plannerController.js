// =============================================
// controllers/plannerController.js - AI Study Planner
// =============================================
// This is a dummy/mock AI planner.
// It accepts tasks and generates a study plan without any real AI.
// You can later connect this to OpenAI/Gemini for real AI responses.

// ---- @route   POST /api/planner/generate ----
// ---- @desc    Generate a study plan from given tasks ----
// ---- @access  Private ----
const generatePlan = async (req, res) => {
  try {
    const { tasks, availableHoursPerDay } = req.body;

    // Validate input
    if (!tasks || !Array.isArray(tasks) || tasks.length === 0) {
      return res.status(400).json({
        message: "Please provide an array of tasks",
        example: {
          tasks: [
            { name: "Math Assignment", deadline: "2024-12-15", estimatedHours: 3 },
            { name: "Physics Lab Report", deadline: "2024-12-17", estimatedHours: 2 },
          ],
          availableHoursPerDay: 4,
        },
      });
    }

    const hoursPerDay = availableHoursPerDay || 4;

    // ---- Mock Plan Generation Logic ----
    // Sort tasks by deadline (earliest first)
    const sortedTasks = [...tasks].sort((a, b) => {
      if (a.deadline && b.deadline) {
        return new Date(a.deadline) - new Date(b.deadline);
      }
      return 0;
    });

    // Generate a day-by-day plan
    const plan = [];
    let currentDay = 1;
    let hoursUsedToday = 0;

    sortedTasks.forEach((task) => {
      const taskHours = task.estimatedHours || 2; // Default 2 hours per task
      const taskName = task.name || "Unnamed Task";

      let hoursRemaining = taskHours;

      while (hoursRemaining > 0) {
        const availableNow = hoursPerDay - hoursUsedToday;
        const workToday = Math.min(hoursRemaining, availableNow);

        plan.push({
          day: `Day ${currentDay}`,
          task: taskName,
          hours: workToday,
          tip: getTip(taskName),
        });

        hoursRemaining -= workToday;
        hoursUsedToday += workToday;

        if (hoursUsedToday >= hoursPerDay) {
          currentDay++;
          hoursUsedToday = 0;
        }
      }
    });

    // Group plan entries by day for cleaner output
    const groupedPlan = {};
    plan.forEach((entry) => {
      if (!groupedPlan[entry.day]) {
        groupedPlan[entry.day] = { tasks: [], totalHours: 0 };
      }
      groupedPlan[entry.day].tasks.push({ task: entry.task, hours: entry.hours, tip: entry.tip });
      groupedPlan[entry.day].totalHours += entry.hours;
    });

    res.json({
      message: "📅 Here's your study plan!",
      totalDays: currentDay,
      hoursPerDay,
      plan: groupedPlan,
      generalAdvice: [
        "Take a 5-minute break every 25 minutes (Pomodoro Technique)",
        "Study the hardest subjects when your energy is highest",
        "Review notes within 24 hours to improve retention",
        "Stay hydrated and get at least 7 hours of sleep",
      ],
    });
  } catch (error) {
    res.status(500).json({ message: "Error generating plan", error: error.message });
  }
};

// ---- @route   POST /api/planner/tips ----
// ---- @desc    Get study tips for a specific subject ----
// ---- @access  Private ----
const getStudyTips = async (req, res) => {
  try {
    const { subject } = req.body;

    const tips = {
      math: [
        "Practice problems daily — math is learned by doing, not reading",
        "Understand the concept before memorizing formulas",
        "Work through solved examples step by step",
        "Teach the concept to someone else to test your understanding",
      ],
      physics: [
        "Draw diagrams for every problem",
        "Focus on understanding units and dimensions",
        "Relate concepts to real-world examples",
        "Practice numerical problems from previous exams",
      ],
      programming: [
        "Code every day, even if just for 30 minutes",
        "Build small projects to apply what you learn",
        "Read other people's code on GitHub",
        "Debug without AI first — it builds problem-solving skills",
      ],
      history: [
        "Create timelines to visualize events",
        "Focus on cause-effect relationships",
        "Use flashcards for dates and key figures",
        "Read from multiple sources for different perspectives",
      ],
      default: [
        "Create a consistent study schedule",
        "Use active recall instead of re-reading",
        "Take handwritten notes — it improves memory",
        "Study in a quiet, distraction-free environment",
      ],
    };

    // Find tips for subject (case insensitive), fallback to default
    const subjectKey = subject
      ? Object.keys(tips).find((key) => subject.toLowerCase().includes(key))
      : null;

    const selectedTips = subjectKey ? tips[subjectKey] : tips.default;

    res.json({
      subject: subject || "General",
      tips: selectedTips,
    });
  } catch (error) {
    res.status(500).json({ message: "Error fetching tips", error: error.message });
  }
};

// ---- Helper: Get a relevant tip based on task name ----
const getTip = (taskName) => {
  const name = taskName.toLowerCase();
  if (name.includes("math") || name.includes("calculus")) return "Solve at least 5 practice problems";
  if (name.includes("code") || name.includes("program")) return "Write the code by hand first, then type it";
  if (name.includes("essay") || name.includes("report")) return "Outline first, then write paragraph by paragraph";
  if (name.includes("exam") || name.includes("test")) return "Focus on past papers and key concepts";
  return "Use Pomodoro: 25 min focus, 5 min break";
};

module.exports = { generatePlan, getStudyTips };
