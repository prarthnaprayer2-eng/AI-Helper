// =============================================
// controllers/noteController.js - Notes CRUD
// =============================================

const Note = require("../models/Note");

// ---- @route   GET /api/notes ----
// ---- @desc    Get all notes for logged-in user ----
// ---- @access  Private ----
const getNotes = async (req, res) => {
  try {
    // Only fetch notes that belong to the current user
    // Sort by newest first (-1 = descending)
    const notes = await Note.find({ user: req.user._id }).sort({ createdAt: -1 });

    res.json({ count: notes.length, notes });
  } catch (error) {
    res.status(500).json({ message: "Error fetching notes", error: error.message });
  }
};

// ---- @route   POST /api/notes ----
// ---- @desc    Create a new note ----
// ---- @access  Private ----
const createNote = async (req, res) => {
  try {
    const { title, content, subject, tags } = req.body;

    if (!title || !content) {
      return res.status(400).json({ message: "Title and content are required" });
    }

    const note = await Note.create({
      user: req.user._id, // Attach the logged-in user's ID
      title,
      content,
      subject,
      tags,
    });

    res.status(201).json({ message: "Note created!", note });
  } catch (error) {
    res.status(500).json({ message: "Error creating note", error: error.message });
  }
};

// ---- @route   GET /api/notes/:id ----
// ---- @desc    Get a single note by ID ----
// ---- @access  Private ----
const getNoteById = async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).json({ message: "Note not found" });
    }

    // Security check: make sure this note belongs to the requesting user
    if (note.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to view this note" });
    }

    res.json({ note });
  } catch (error) {
    res.status(500).json({ message: "Error fetching note", error: error.message });
  }
};

// ---- @route   DELETE /api/notes/:id ----
// ---- @desc    Delete a note ----
// ---- @access  Private ----
const deleteNote = async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).json({ message: "Note not found" });
    }

    // Security check: only owner can delete
    if (note.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to delete this note" });
    }

    await note.deleteOne();

    res.json({ message: "Note deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting note", error: error.message });
  }
};

module.exports = { getNotes, createNote, getNoteById, deleteNote };
