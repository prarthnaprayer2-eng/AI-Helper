// =============================================
// controllers/authController.js - Signup & Login
// =============================================

const jwt = require("jsonwebtoken");
const User = require("../models/User");

// ---- Helper: Generate JWT Token ----
const generateToken = (userId) => {
  return jwt.sign(
    { id: userId }, // Payload: what we store in the token
    process.env.JWT_SECRET, // Secret key to sign with
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" } // Token expires in 7 days
  );
};

// ---- @route   POST /api/auth/signup ----
// ---- @desc    Register a new user ----
// ---- @access  Public ----
const signup = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Validate that all fields are present
    if (!name || !email || !password) {
      return res.status(400).json({ message: "Please provide name, email, and password" });
    }

    // Check if a user with this email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists with this email" });
    }

    // Create new user (password gets hashed by the pre-save hook in User model)
    const user = await User.create({ name, email, password });

    // Return user info + token (don't return the password!)
    res.status(201).json({
      message: "Account created successfully!",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
      token: generateToken(user._id),
    });
  } catch (error) {
    console.error("Signup Error:", error.message);
    res.status(500).json({ message: "Server error during signup", error: error.message });
  }
};

// ---- @route   POST /api/auth/login ----
// ---- @desc    Login existing user ----
// ---- @access  Public ----
const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate inputs
    if (!email || !password) {
      return res.status(400).json({ message: "Please provide email and password" });
    }

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    // Check if entered password matches the stored hashed password
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    // Login successful — return token
    res.json({
      message: "Login successful!",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
      token: generateToken(user._id),
    });
  } catch (error) {
    console.error("Login Error:", error.message);
    res.status(500).json({ message: "Server error during login", error: error.message });
  }
};

// ---- @route   GET /api/auth/me ----
// ---- @desc    Get current logged-in user's profile ----
// ---- @access  Private (requires token) ----
const getMe = async (req, res) => {
  try {
    // req.user is set by the protect middleware
    res.json({
      user: {
        id: req.user._id,
        name: req.user.name,
        email: req.user.email,
        createdAt: req.user.createdAt,
      },
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = { signup, login, getMe };
