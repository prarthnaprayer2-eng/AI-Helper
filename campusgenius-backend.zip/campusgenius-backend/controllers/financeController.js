// =============================================
// controllers/financeController.js
// =============================================

const Expense = require("../models/Expense");

// ---- @route   GET /api/finance ----
// ---- @desc    Get all expenses + summary for logged-in user ----
// ---- @access  Private ----
const getExpenses = async (req, res) => {
  try {
    const expenses = await Expense.find({ user: req.user._id }).sort({ date: -1 });

    // Calculate total amount spent
    const totalSpent = expenses.reduce((sum, exp) => sum + exp.amount, 0);

    // Group expenses by category
    const byCategory = {};
    expenses.forEach((exp) => {
      if (!byCategory[exp.category]) {
        byCategory[exp.category] = 0;
      }
      byCategory[exp.category] += exp.amount;
    });

    res.json({
      count: expenses.length,
      totalSpent: Math.round(totalSpent * 100) / 100, // Round to 2 decimals
      byCategory,
      expenses,
    });
  } catch (error) {
    res.status(500).json({ message: "Error fetching expenses", error: error.message });
  }
};

// ---- @route   POST /api/finance ----
// ---- @desc    Add a new expense ----
// ---- @access  Private ----
const addExpense = async (req, res) => {
  try {
    const { title, amount, category, date, note } = req.body;

    if (!title || !amount) {
      return res.status(400).json({ message: "Title and amount are required" });
    }

    if (amount <= 0) {
      return res.status(400).json({ message: "Amount must be greater than 0" });
    }

    const expense = await Expense.create({
      user: req.user._id,
      title,
      amount,
      category,
      date: date ? new Date(date) : Date.now(),
      note,
    });

    res.status(201).json({ message: "Expense added!", expense });
  } catch (error) {
    res.status(500).json({ message: "Error adding expense", error: error.message });
  }
};

// ---- @route   DELETE /api/finance/:id ----
// ---- @desc    Delete an expense ----
// ---- @access  Private ----
const deleteExpense = async (req, res) => {
  try {
    const expense = await Expense.findById(req.params.id);

    if (!expense) {
      return res.status(404).json({ message: "Expense not found" });
    }

    if (expense.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await expense.deleteOne();
    res.json({ message: "Expense deleted" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting expense", error: error.message });
  }
};

// ---- @route   GET /api/finance/summary ----
// ---- @desc    Get monthly spending summary ----
// ---- @access  Private ----
const getMonthlySummary = async (req, res) => {
  try {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

    // Fetch only this month's expenses
    const monthlyExpenses = await Expense.find({
      user: req.user._id,
      date: { $gte: startOfMonth, $lte: endOfMonth },
    });

    const totalThisMonth = monthlyExpenses.reduce((sum, e) => sum + e.amount, 0);

    // Category breakdown for this month
    const breakdown = {};
    monthlyExpenses.forEach((e) => {
      breakdown[e.category] = (breakdown[e.category] || 0) + e.amount;
    });

    res.json({
      month: now.toLocaleString("default", { month: "long", year: "numeric" }),
      totalSpent: Math.round(totalThisMonth * 100) / 100,
      transactionCount: monthlyExpenses.length,
      categoryBreakdown: breakdown,
    });
  } catch (error) {
    res.status(500).json({ message: "Error fetching monthly summary", error: error.message });
  }
};

module.exports = { getExpenses, addExpense, deleteExpense, getMonthlySummary };
