// =============================================
// controllers/attendanceController.js
// =============================================

const Attendance = require("../models/Attendance");

// ---- Helper: Calculate attendance percentage ----
const calcPercentage = (attended, total) => {
  if (total === 0) return 0;
  return Math.round((attended / total) * 100);
};

// ---- @route   GET /api/attendance ----
// ---- @desc    Get all subjects + attendance for logged-in user ----
// ---- @access  Private ----
const getAttendance = async (req, res) => {
  try {
    const records = await Attendance.find({ user: req.user._id }).sort({ subject: 1 });

    res.json({ count: records.length, attendance: records });
  } catch (error) {
    res.status(500).json({ message: "Error fetching attendance", error: error.message });
  }
};

// ---- @route   POST /api/attendance ----
// ---- @desc    Add a new subject ----
// ---- @access  Private ----
const addSubject = async (req, res) => {
  try {
    const { subject, totalClasses, attendedClasses, minimumRequired } = req.body;

    if (!subject) {
      return res.status(400).json({ message: "Subject name is required" });
    }

    // Check if subject already exists for this user
    const existing = await Attendance.findOne({ user: req.user._id, subject });
    if (existing) {
      return res.status(400).json({ message: "Subject already exists" });
    }

    const total = totalClasses || 0;
    const attended = attendedClasses || 0;
    const percentage = calcPercentage(attended, total);

    const record = await Attendance.create({
      user: req.user._id,
      subject,
      totalClasses: total,
      attendedClasses: attended,
      percentage,
      minimumRequired: minimumRequired || 75,
    });

    res.status(201).json({ message: "Subject added!", attendance: record });
  } catch (error) {
    res.status(500).json({ message: "Error adding subject", error: error.message });
  }
};

// ---- @route   PUT /api/attendance/:id ----
// ---- @desc    Update attendance for a subject ----
// ---- @access  Private ----
const updateAttendance = async (req, res) => {
  try {
    const record = await Attendance.findById(req.params.id);

    if (!record) {
      return res.status(404).json({ message: "Attendance record not found" });
    }

    // Security: only owner can update
    if (record.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    const { totalClasses, attendedClasses, minimumRequired } = req.body;

    // Update only provided fields (fallback to existing values)
    record.totalClasses = totalClasses ?? record.totalClasses;
    record.attendedClasses = attendedClasses ?? record.attendedClasses;
    record.minimumRequired = minimumRequired ?? record.minimumRequired;

    // Recalculate percentage after update
    record.percentage = calcPercentage(record.attendedClasses, record.totalClasses);

    await record.save();

    // Tell user if they're below minimum requirement
    const status =
      record.percentage >= record.minimumRequired
        ? "✅ Safe"
        : `⚠️ Below required ${record.minimumRequired}%`;

    res.json({
      message: "Attendance updated!",
      status,
      attendance: record,
    });
  } catch (error) {
    res.status(500).json({ message: "Error updating attendance", error: error.message });
  }
};

// ---- @route   DELETE /api/attendance/:id ----
// ---- @desc    Remove a subject ----
// ---- @access  Private ----
const deleteSubject = async (req, res) => {
  try {
    const record = await Attendance.findById(req.params.id);

    if (!record) {
      return res.status(404).json({ message: "Record not found" });
    }

    if (record.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await record.deleteOne();
    res.json({ message: "Subject removed successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting subject", error: error.message });
  }
};

module.exports = { getAttendance, addSubject, updateAttendance, deleteSubject };
