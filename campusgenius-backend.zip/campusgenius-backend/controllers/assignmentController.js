// =============================================
// controllers/assignmentController.js
// =============================================

const Assignment = require("../models/Assignment");

// ---- @route   GET /api/assignments ----
// ---- @desc    Get all assignments for logged-in user ----
// ---- @access  Private ----
const getAssignments = async (req, res) => {
  try {
    const assignments = await Assignment.find({ user: req.user._id }).sort({ deadline: 1 }); // Sort by nearest deadline

    res.json({ count: assignments.length, assignments });
  } catch (error) {
    res.status(500).json({ message: "Error fetching assignments", error: error.message });
  }
};

// ---- @route   GET /api/assignments/upcoming ----
// ---- @desc    Get only upcoming (incomplete) assignments ----
// ---- @access  Private ----
const getUpcoming = async (req, res) => {
  try {
    const now = new Date();

    // Find assignments that are: not completed AND deadline is in the future
    const upcoming = await Assignment.find({
      user: req.user._id,
      isCompleted: false,
      deadline: { $gte: now }, // $gte = greater than or equal to
    }).sort({ deadline: 1 });

    res.json({ count: upcoming.length, assignments: upcoming });
  } catch (error) {
    res.status(500).json({ message: "Error fetching upcoming assignments", error: error.message });
  }
};

// ---- @route   POST /api/assignments ----
// ---- @desc    Add a new assignment ----
// ---- @access  Private ----
const createAssignment = async (req, res) => {
  try {
    const { title, subject, description, deadline, priority } = req.body;

    if (!title || !deadline) {
      return res.status(400).json({ message: "Title and deadline are required" });
    }

    const assignment = await Assignment.create({
      user: req.user._id,
      title,
      subject,
      description,
      deadline: new Date(deadline), // Convert string to Date
      priority,
    });

    res.status(201).json({ message: "Assignment added!", assignment });
  } catch (error) {
    res.status(500).json({ message: "Error creating assignment", error: error.message });
  }
};

// ---- @route   PUT /api/assignments/:id/complete ----
// ---- @desc    Mark assignment as complete/incomplete ----
// ---- @access  Private ----
const toggleComplete = async (req, res) => {
  try {
    const assignment = await Assignment.findById(req.params.id);

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" });
    }

    if (assignment.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    // Toggle the completion status
    assignment.isCompleted = !assignment.isCompleted;
    await assignment.save();

    res.json({
      message: assignment.isCompleted ? "✅ Marked as complete!" : "↩️ Marked as incomplete",
      assignment,
    });
  } catch (error) {
    res.status(500).json({ message: "Error updating assignment", error: error.message });
  }
};

// ---- @route   DELETE /api/assignments/:id ----
// ---- @desc    Delete an assignment ----
// ---- @access  Private ----
const deleteAssignment = async (req, res) => {
  try {
    const assignment = await Assignment.findById(req.params.id);

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" });
    }

    if (assignment.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await assignment.deleteOne();
    res.json({ message: "Assignment deleted" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting assignment", error: error.message });
  }
};

module.exports = { getAssignments, getUpcoming, createAssignment, toggleComplete, deleteAssignment };
