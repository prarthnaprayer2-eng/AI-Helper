// =============================================
// models/Attendance.js - Attendance Schema
// =============================================

const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    subject: {
      type: String,
      required: [true, "Subject name is required"],
      trim: true,
    },
    totalClasses: {
      type: Number,
      default: 0,
    },
    attendedClasses: {
      type: Number,
      default: 0,
    },
    // Calculated percentage — stored for quick access
    percentage: {
      type: Number,
      default: 0,
    },
    minimumRequired: {
      type: Number,
      default: 75, // Most colleges require 75% attendance
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Attendance", attendanceSchema);
