// =============================================
// models/Assignment.js - Assignment Schema
// =============================================

const mongoose = require("mongoose");

const assignmentSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    title: {
      type: String,
      required: [true, "Assignment title is required"],
      trim: true,
    },
    subject: {
      type: String,
      trim: true,
      default: "General",
    },
    description: {
      type: String,
      default: "",
    },
    deadline: {
      type: Date,
      required: [true, "Deadline is required"],
    },
    isCompleted: {
      type: Boolean,
      default: false, // Starts as incomplete
    },
    priority: {
      type: String,
      enum: ["low", "medium", "high"], // Only these values allowed
      default: "medium",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Assignment", assignmentSchema);
