// =============================================
// models/Expense.js - Finance Tracker Schema
// =============================================

const mongoose = require("mongoose");

const expenseSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    title: {
      type: String,
      required: [true, "Expense title is required"],
      trim: true,
    },
    amount: {
      type: Number,
      required: [true, "Amount is required"],
      min: [0, "Amount cannot be negative"],
    },
    category: {
      type: String,
      // Common student expense categories
      enum: ["food", "transport", "books", "entertainment", "rent", "health", "shopping", "other"],
      default: "other",
    },
    date: {
      type: Date,
      default: Date.now, // Defaults to today
    },
    note: {
      type: String,
      default: "",
    },
    // Monthly budget set by the user (optional)
    monthlyBudget: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Expense", expenseSchema);
