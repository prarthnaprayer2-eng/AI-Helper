// =============================================
// models/Note.js - Note Schema
// =============================================

const mongoose = require("mongoose");

const noteSchema = new mongoose.Schema(
  {
    // Reference to the User who created this note
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    title: {
      type: String,
      required: [true, "Note title is required"],
      trim: true,
    },
    content: {
      type: String,
      required: [true, "Note content is required"],
    },
    subject: {
      type: String,
      trim: true,
      default: "General",
    },
    tags: {
      type: [String], // Array of strings like ["exam", "important"]
      default: [],
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Note", noteSchema);
