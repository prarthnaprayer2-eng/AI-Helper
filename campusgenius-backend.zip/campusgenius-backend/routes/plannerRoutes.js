// =============================================
// routes/plannerRoutes.js
// =============================================

const express = require("express");
const router = express.Router();
const { generatePlan, getStudyTips } = require("../controllers/plannerController");
const { protect } = require("../middleware/authMiddleware");

// All planner routes require authentication
router.use(protect);

// POST /api/planner/generate → Generate a study plan from task list
// POST /api/planner/tips     → Get study tips for a subject
router.post("/generate", generatePlan);
router.post("/tips", getStudyTips);

module.exports = router;
