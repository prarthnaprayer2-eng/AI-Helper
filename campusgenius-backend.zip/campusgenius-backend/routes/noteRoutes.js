// =============================================
// routes/noteRoutes.js
// =============================================

const express = require("express");
const router = express.Router();
const {
  getNotes,
  createNote,
  getNoteById,
  deleteNote,
} = require("../controllers/noteController");
const { protect } = require("../middleware/authMiddleware");

// Apply protect middleware to ALL note routes
// This means every request to /api/notes/* must have a valid token
router.use(protect);

// GET  /api/notes       → Get all notes for logged-in user
// POST /api/notes       → Create a new note
router.get("/", getNotes);
router.post("/", createNote);

// GET    /api/notes/:id → Get a single note
// DELETE /api/notes/:id → Delete a note
router.get("/:id", getNoteById);
router.delete("/:id", deleteNote);

module.exports = router;
