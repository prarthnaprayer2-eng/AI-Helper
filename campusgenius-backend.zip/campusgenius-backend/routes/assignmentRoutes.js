// =============================================
// routes/assignmentRoutes.js
// =============================================

const express = require("express");
const router = express.Router();
const {
  getAssignments,
  getUpcoming,
  createAssignment,
  toggleComplete,
  deleteAssignment,
} = require("../controllers/assignmentController");
const { protect } = require("../middleware/authMiddleware");

// All assignment routes require authentication
router.use(protect);

// GET /api/assignments          → All assignments (sorted by deadline)
// GET /api/assignments/upcoming → Only incomplete + future assignments
// POST /api/assignments         → Add new assignment
router.get("/", getAssignments);
router.get("/upcoming", getUpcoming); // NOTE: Must be defined BEFORE /:id to avoid conflict
router.post("/", createAssignment);

// PUT    /api/assignments/:id/complete → Toggle done/undone
// DELETE /api/assignments/:id          → Delete assignment
router.put("/:id/complete", toggleComplete);
router.delete("/:id", deleteAssignment);

module.exports = router;
