// =============================================
// routes/financeRoutes.js
// =============================================

const express = require("express");
const router = express.Router();
const {
  getExpenses,
  addExpense,
  deleteExpense,
  getMonthlySummary,
} = require("../controllers/financeController");
const { protect } = require("../middleware/authMiddleware");

// All finance routes require authentication
router.use(protect);

// GET  /api/finance         → All expenses + total + category breakdown
// POST /api/finance         → Add new expense
router.get("/", getExpenses);
router.post("/", addExpense);

// GET    /api/finance/summary  → This month's summary (must be before /:id)
// DELETE /api/finance/:id      → Delete an expense
router.get("/summary", getMonthlySummary);
router.delete("/:id", deleteExpense);

module.exports = router;
