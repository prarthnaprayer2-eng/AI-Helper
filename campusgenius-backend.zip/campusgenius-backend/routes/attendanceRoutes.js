// =============================================
// routes/attendanceRoutes.js
// =============================================

const express = require("express");
const router = express.Router();
const {
  getAttendance,
  addSubject,
  updateAttendance,
  deleteSubject,
} = require("../controllers/attendanceController");
const { protect } = require("../middleware/authMiddleware");

// All attendance routes require authentication
router.use(protect);

// GET  /api/attendance      → Get all subjects + attendance %
// POST /api/attendance      → Add a new subject
router.get("/", getAttendance);
router.post("/", addSubject);

// PUT    /api/attendance/:id → Update attendance numbers
// DELETE /api/attendance/:id → Remove a subject
router.put("/:id", updateAttendance);
router.delete("/:id", deleteSubject);

module.exports = router;
